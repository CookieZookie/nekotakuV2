const snoowrap = require('snoowrap');
const Discord = require('discord.js');
require('dotenv').config();

let i = 0;
let post = '';


const r = new snoowrap({
  userAgent: 'Nekotaku',
  clientId: process.env.CLIENTID,
  clientSecret: process.env.CLIENTSECRET,
  refreshToken: process.env.REFRESHTOKEN
});


module.exports = function (msg, args) {

  async function getPosts() {
    start: while(true) {
    const post = await r.getSubreddit('animegifs').getRandomSubmission().then(post => post);
    var info = {
      id: post.id,
      url: post.url,
      score: post.score,
      flair: post.link_flair_text,
      video: post.is_video
    }
    console.log(info);
    if (info.video == true) continue start;
    if (info.video == false) break;
  }
    
    const imgembed = new Discord.MessageEmbed()
      .setColor('#feb7c4')
      .setImage(info.url)
      .setFooter('Clips provided by r/animegifs', info.url)
      .setTimestamp();


    msg.channel.send(imgembed);

}
  getPosts()

}